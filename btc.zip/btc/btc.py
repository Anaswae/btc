import asyncio
import logging
import re
import time
import os
import sys
import random

logging.basicConfig(level=logging.ERROR)

from telethon import TelegramClient, events
from telethon.tl.functions.channels import JoinChannelRequest
from telethon.tl.functions.messages import GetBotCallbackAnswerRequest
from telethon.tl.types import UpdateNewMessage, PeerChannel
from datetime import datetime
from colorama import Fore, init as color_ama
color_ama(autoreset=True)
os.system('cls' if os.name=='nt' else 'clear')
api_id = 800812
api_hash = 'db55ad67a98df35667ca788b97f771f5'

chnl = '@ETH_Trend_Group'

def print_msg_time(message):
	print('[' + Fore.CYAN + f'{datetime.now().strftime("%H:%M:%S")}' + Fore.RESET + f'] {message}')

async def main():

	if len(sys.argv) < 2:
		print('Usage: python start.py phone_number')
		print('-> Input number in international format (example: +639162995600)\n')
		e = input('Press any key to exit...')
		exit(1)
		
	phone_number = sys.argv[1]
	
	if not os.path.exists("data"):
		os.mkdir("data")
   
    # Connect to client
	client = TelegramClient('data/' + phone_number, api_id, api_hash)
	await client.start(phone_number)
	me = await client.get_me()
	
	# BACA INI DULU
	"""row 0 = event (/e)
	   row 3 = ods (/o)
	=============================
		a = row ( hanya 0 dan 5 )
				( contoh row = #
							   #
							   #
							   # )
							
		b = button ( berurutan dari kiri ke kanan ok? )
				   ( contoh button = # # # #)
	"""
	#Aturnya Di Sini
	a=0
	b=0
	# DONASI
	# PM 
	
	print_msg_time(Fore.GREEN + f'Welcome : ({me.first_name}) to ' + chnl+ Fore.RESET)
	
	# Start Claim / Click
	@client.on(events.NewMessage(pattern ="⛅ FORECAST #", chats=chnl, incoming=True))
	async def claim(event):
		ori = event.original_update.message
		data = ori.reply_markup.rows[a].buttons[b].data
		await asyncio.sleep(2)
		await client(GetBotCallbackAnswerRequest(
					chnl,
					event.original_update.message.id,
					data=data))
		print_msg_time(Fore.YELLOW+ '>> YOU Click ' + str(data) + Fore.RESET)
	
	
	await client.run_until_disconnected()
	
asyncio.get_event_loop().run_until_complete(main())
